# Admin paswoord - 1234567890
# Admin Email - rejanasim611@gmail.com

Signup ->
![alt text](image-12.png)
Login ->
![alt text](image-13.png)

navebar-> 
![alt text](image.png), ![alt text](image-1.png)

Banner ->
![alt text](image-2.png)

Filter ->
![alt text](image-4.png)
![alt text](image-5.png)

![alt text](image-3.png)

Footer ->
![alt text](image-6.png)

Info->
![alt text](image-7.png)

Dashboard ->
![alt text](image-8.png)

Buy Now ->
![alt text](image-9.png)
![alt text](image-10.png)

![alt text](image-11.png)