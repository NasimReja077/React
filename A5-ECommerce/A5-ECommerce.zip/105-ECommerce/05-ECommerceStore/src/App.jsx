import React, { Children } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Home from './pages/home/HomePage';
import Order from './pages/Order/Order';
import CartPage from './pages/cart/CartPage';
import Dashboard from './pages/admin/dashboard/Dashboard';
import NoPage from './pages/noPage/NoPage';
import MyState from './context/MyState';
import Login from './pages/registration/Login';
import Signup from './pages/registration/Signup';
import ProductInfo from './pages/productInfo/ProductInfo';
import AddProduct from './pages/admin/pages/AddProduct';
import UpdateProduct from './pages/admin/pages/UpdateProduct';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import AllProduct from './pages/allProduct/AllProduct';
import ReturnPolicy from './pages/Return Policy/ReturnPolicy';
import About from './pages/about/About';

function App() {
  return (
    <MyState>
      <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/allproduct" element={<AllProduct/>} />
          <Route path="/order" element={
            <ProtectedRoutes>
              <Order />
            </ProtectedRoutes>
            } />
          <Route path="/cart" element={<CartPage />} />
          <Route path="/dashboard" element={
            <ProtectedRoutesForAdmin>
              <Dashboard />
            </ProtectedRoutesForAdmin>
            } />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/productinfo/:id" element={<ProductInfo />} />
          <Route path="/addproduct" element={
            <ProtectedRoutesForAdmin>
              <AddProduct />
            </ProtectedRoutesForAdmin>
            } />
          <Route path="/updateproduct" element={
            <ProtectedRoutesForAdmin>
              <UpdateProduct />
            </ProtectedRoutesForAdmin>
            } />
          <Route path="/*" element={<NoPage />} />
          <Route path="/returnPolicy" element={<ReturnPolicy />} />
          <Route path="/about" element={<About />} />
        </Routes>
        <ToastContainer />
      </Router>
    </MyState>
  );
}
export default App;
// User
export const ProtectedRoutes = ({ children }) => {
  if (localStorage.getItem('currentUser')) {
    return children;
  } else {
    return <Navigate to='/login' />;
  }
};
// Admin
export const ProtectedRoutesForAdmin = ({ children }) => {
  const admin = JSON.parse(localStorage.getItem('user'));
  console.log(admin.email); // Corrected to access email directly

  if (admin.email === 'rejanasim611@gmail.com') {
    return children;
  } else {
    return <Navigate to='/login' />;
  }
};