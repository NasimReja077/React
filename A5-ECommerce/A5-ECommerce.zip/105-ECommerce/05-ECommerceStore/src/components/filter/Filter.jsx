import React, { useContext } from 'react';
import myContext from '../../context/myContext';
import { FaSearch, FaRedo } from 'react-icons/fa';
import { IoFilterSharp } from 'react-icons/io5';

function Filter() {
  const context = useContext(myContext);
  const { mode, searchkey, setSearchkey, filterType, setFilterType, filterPrice, setFilterPrice, product } = context;

  const resetFilters = () => {
    setSearchkey('');
    setFilterType('');
    setFilterPrice('');
  };

  return (
    <div className='container mx-auto px-4 mt-5'>
      <div className={`p-5 rounded-lg drop-shadow-xl border ${mode === 'dark' ? 'bg-gray-800 border-gray-700 text-white' : 'bg-white border-gray-200 text-gray-900'}`}>
        <div className="relative mb-4">
          <div className="absolute flex items-center ml-2 h-full">
            <FaSearch className={`w-4 h-4 ${mode === 'dark' ? 'text-gray-400' : 'text-gray-600'}`} />
          </div>
          <input
            type="text"
            name="searchkey"
            id="searchkey"
            value={searchkey}
            onChange={e => setSearchkey(e.target.value)}
            placeholder="Search here"
            className={`pl-10 pr-4 py-3 w-full rounded-md border outline-none focus:ring-2 ${mode === 'dark' ? 'bg-gray-700 border-gray-600 focus:ring-indigo-500 text-white' : 'bg-gray-100 border-gray-300 focus:ring-indigo-500 text-gray-900'}`}
          />
        </div>
        <div className="flex items-center justify-between mb-4">
          <p className="font-bold flex items-center">
            <IoFilterSharp className="mr-2" /> Filters
          </p>
          <button
            onClick={resetFilters}
            className={`px-4 py-2 rounded-md flex items-center transition ${mode === 'dark' ? 'bg-gray-700 text-white hover:bg-gray-600' : 'bg-gray-200 text-gray-800 hover:bg-gray-300'}`}
          >
            <FaRedo className="mr-2" /> Reset Filters
          </button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className={`px-4 py-3 w-full rounded-md border outline-none focus:ring-2 ${mode === 'dark' ? 'bg-gray-700 border-gray-600 focus:ring-indigo-500 text-white' : 'bg-gray-100 border-gray-300 focus:ring-indigo-500 text-gray-900'}`}
          >
            <option value="">Select Category</option>
            {product.map((item, index) => (
              <option key={index} value={item.category}>{item.category}</option>
            ))}
          </select>
          <select
            value={filterPrice}
            onChange={(e) => setFilterPrice(e.target.value)}
            className={`px-4 py-3 w-full rounded-md border outline-none focus:ring-2 ${mode === 'dark' ? 'bg-gray-700 border-gray-600 focus:ring-indigo-500 text-white' : 'bg-gray-100 border-gray-300 focus:ring-indigo-500 text-gray-900'}`}
          >
            <option value="">Select Price</option>
            {product.map((item, index) => (
              <option key={index} value={item.price}>{item.price}</option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
}

export default Filter;
