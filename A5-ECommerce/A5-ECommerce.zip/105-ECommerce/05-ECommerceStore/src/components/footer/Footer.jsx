import { useContext } from 'react';
import { Link } from 'react-router-dom';
import myContext from '../../context/myContext';
import { FaFacebookF, FaTwitter, FaInstagram, FaLinkedinIn } from 'react-icons/fa';
import backgroundVideo from '../../assets/backgroundVideo.mp4';

function Footer() {
  const context = useContext(myContext);
  const { mode } = context;

  const footerBgColor = mode === 'dark' ? 'rgba(46, 49, 55, 0.9)' : 'rgba(241, 241, 241, 0.9)';
  const footerTextColor = mode === 'dark' ? '#ffffff' : '#000000';
  const footerLinkColor = mode === 'dark' ? '#9ca3af' : '#4b5563';
  const hoverLinkColor = mode === 'dark' ? '#ffffff' : '#000000';

  return (
    <div className="relative">
      <video
        autoPlay
        loop
        muted
        className="absolute inset-0 w-full h-full object-cover"
        style={{ filter: 'blur(8px)', zIndex: -1 }}
      >
        <source src={backgroundVideo} type="video/mp4" />
      </video>
      <footer
        className="text-gray-600 body-font"
        style={{
          backgroundColor: footerBgColor,
          color: footerTextColor,
        }}
      >
        <div className="container px-5 py-24 mx-auto">
          <div className="flex flex-wrap md:text-left text-center order-first">
            <div className="lg:w-1/4 md:w-1/2 w-full px-4 mb-10">
              <h2 className="title-font font-semibold text-lg mb-3" style={{ color: footerTextColor }}>
                Categories
              </h2>
              <nav className="list-none">
                <li className="mb-2">
                  <Link
                    className="hover:text-gray-800 transition duration-300"
                    style={{ color: footerLinkColor, hover: hoverLinkColor }}
                    to="/"
                  >
                    Home
                  </Link>
                </li>
                <li className="mb-2">
                  <Link
                    className="hover:text-gray-800 transition duration-300"
                    style={{ color: footerLinkColor, hover: hoverLinkColor }}
                    to="/order"
                  >
                    Order
                  </Link>
                </li>
                
                <li className="mb-2">
                  <Link
                    className="hover:text-gray-800 transition duration-300"
                    style={{ color: footerLinkColor, hover: hoverLinkColor }}
                    to="/cart"
                  >
                    Cart
                  </Link>
                </li>

                <li className="mb-2">
                  <Link
                    className="hover:text-gray-800 transition duration-300"
                    style={{ color: footerLinkColor, hover: hoverLinkColor }}
                    to="/allproduct"
                  >
                    AllProduct
                  </Link>
                </li>
              </nav>
            </div>
            <div className="lg:w-1/4 md:w-1/2 w-full px-4 mb-10">
              <h2 className="title-font font-semibold text-lg mb-3" style={{ color: footerTextColor }}>
                Customer Service
              </h2>
              <nav className="list-none">
                <li className="mb-2">
                  <Link
                    className="hover:text-gray-800 transition duration-300"
                    style={{ color: footerLinkColor, hover: hoverLinkColor }}
                    to="/returnPolicy"
                  >
                    Return Policy
                  </Link>
                </li>
                <li className="mb-2">
                  <Link
                    className="hover:text-gray-800 transition duration-300"
                    style={{ color: footerLinkColor, hover: hoverLinkColor }}
                    to="/about"
                  >
                    About
                  </Link>
                </li>
                <li className="mb-2">
                  <Link
                    className="hover:text-gray-800 transition duration-300"
                    style={{ color: footerLinkColor, hover: hoverLinkColor }}
                    to="/contact"
                  >
                    Contact Us
                  </Link>
                </li>
              </nav>
            </div>
            <div className="lg:w-1/4 md:w-1/2 w-full px-4 mb-10">
              <h2 className="title-font font-semibold text-lg mb-3" style={{ color: footerTextColor }}>
                Services
              </h2>
              <nav className="list-none">
                <li className="mb-2">
                  <Link
                    className="hover:text-gray-800 transition duration-300"
                    style={{ color: footerLinkColor, hover: hoverLinkColor }}
                    to="/privacypolicy"
                  >
                    Privacy
                  </Link>
                </li>
              </nav>
            </div>
            <div className="lg:w-1/4 md:w-1/2 w-full px-4 mb-10">
              <img src="https://ecommerce-sk.vercel.app/pay.png" alt="Payment Methods" className="w-full object-cover rounded" />
            </div>
          </div>
        </div>

        <div
          className="bg-gray-200"
          style={{ backgroundColor: mode === 'dark' ? '#37393d' : '#e2e8f0', color: footerTextColor }}
        >
          <div className="container px-5 py-3 mx-auto flex items-center sm:flex-row flex-col">
            <Link to="/" className="flex items-center">
              <h1 className="text-2xl font-bold px-2 py-1 rounded" style={{ color: footerTextColor }}>
                E-Bharat
              </h1>
            </Link>
            <p className="text-sm sm:ml-6 sm:mt-0 mt-4" style={{ color: footerTextColor }}>
              © 2023 E-Bharat —
              <a href="https://twitter.com/knyttneve" rel="noopener noreferrer" className="ml-1" target="_blank" style={{ color: footerLinkColor }}>
                www.ebharat.com
              </a>
            </p>
            <span className="inline-flex sm:ml-auto sm:mt-0 mt-4 justify-center sm:justify-start">
              <a className="text-gray-500 hover:text-blue-500 transition duration-300">
                <FaFacebookF className="w-5 h-5" />
              </a>
              <a className="ml-3 text-gray-500 hover:text-blue-500 transition duration-300">
                <FaTwitter className="w-5 h-5" />
              </a>
              <a className="ml-3 text-gray-500 hover:text-blue-500 transition duration-300">
                <FaInstagram className="w-5 h-5" />
              </a>
              <a className="ml-3 text-gray-500 hover:text-blue-500 transition duration-300">
                <FaLinkedinIn className="w-5 h-5" />
              </a>
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default Footer;
