import React from 'react';
import { Link } from 'react-router-dom';
import { FaShoppingCart } from 'react-icons/fa';

const HeroSection = () => {
  return (
    <div className="relative bg-gray-900 h-screen flex items-center justify-center">
      <video
        autoPlay
        loop
        muted
        className="absolute inset-0 w-full h-full object-cover"
        src="https://media.istockphoto.com/id/1466606962/video/smart-warehouse-management-system-concept-male-worker-working-with-futuristic-animation.mp4?s=mp4-640x640-is&k=20&c=wVibQwGew0N6ERszyZZAqYLsR2_k0J786TKIH6VjxUY="
      />
      <div className="absolute inset-0 bg-black opacity-70"></div>
      <div className="relative max-w-4xl mx-auto px-6 py-24 text-center animate-fadeIn">
        <h1 className="text-5xl font-extrabold tracking-tight sm:text-6xl lg:text-7xl text-white drop-shadow-xl animate-fadeInUp">
          The Ultimate Online Shopping Experience
        </h1>
        <p className="mt-6 max-w-2xl mx-auto text-xl text-gray-300 sm:max-w-3xl drop-shadow-md animate-fadeInUp delay-100">
          Explore exclusive collections and unbeatable prices. Start shopping today!
          <span className='block mt-5'>
            See something cool but you’re on a budget? Zavvyt and add it to your wishlist easily with the barcode reader feature and get notified about its best deals.
          </span>
        </p>
        <div className="mt-10 flex justify-center animate-fadeInUp delay-200">
          <Link
            to="/allproduct"
            className="flex items-center px-8 py-3 border border-transparent text-base font-medium rounded-lg text-white bg-indigo-600 hover:bg-indigo-700 shadow-xl hover:shadow-2xl transition-transform transform hover:scale-110 md:py-4 md:text-lg md:px-10"
          >
            <FaShoppingCart className="mr-2" />
            Shop Now
          </Link>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;
