import { Dialog, Transition } from '@headlessui/react';
import { Fragment, useState } from 'react';

export default function Modal({ name, address, pincode, phoneNumber, setName, setAddress, setPincode, setPhoneNumber, buyNow }) {
    let [isOpen, setIsOpen] = useState(false);

    function closeModal() {
        setIsOpen(false);
    }

    function openModal() {
        setIsOpen(true);
    }

    return (
        <>
            <div className="text-center">
                <button
                    type="button"
                    onClick={openModal}
                    className="w-full bg-gradient-to-r from-purple-500 to-violet-600 py-2 rounded-lg text-white font-bold shadow-md hover:from-purple-600 hover:to-violet-700 transition duration-300"
                >
                    Buy Now
                </button>
            </div>

            <Transition appear show={isOpen} as={Fragment}>
                <Dialog as="div" className="relative z-10" onClose={closeModal}>
                    <Transition.Child
                        as={Fragment}
                        enter="ease-out duration-300"
                        enterFrom="opacity-0"
                        enterTo="opacity-100"
                        leave="ease-in duration-200"
                        leaveFrom="opacity-100"
                        leaveTo="opacity-0"
                    >
                        <div className="fixed inset-0 bg-black bg-opacity-50 transition-opacity" />
                    </Transition.Child>

                    <div className="fixed inset-0 overflow-y-auto">
                        <div className="flex min-h-full items-center justify-center p-4 text-center">
                            <Transition.Child
                                as={Fragment}
                                enter="ease-out duration-300"
                                enterFrom="opacity-0 scale-95"
                                enterTo="opacity-100 scale-100"
                                leave="ease-in duration-200"
                                leaveFrom="opacity-100 scale-100"
                                leaveTo="opacity-0 scale-95"
                            >
                                <Dialog.Panel className="w-full max-w-md transform overflow-hidden rounded-2xl bg-white p-6 text-left align-middle shadow-xl transition-all">
                                    <Dialog.Title as="h3" className="text-lg font-medium leading-6 text-gray-900 mb-4">
                                        Enter Your Details
                                    </Dialog.Title>
                                    <div className="mt-2">
                                        <form className="space-y-4">
                                            <div>
                                                <label htmlFor="name" className="block mb-2 text-sm font-medium text-gray-700">Full Name</label>
                                                <input
                                                    value={name}
                                                    onChange={(e) => setName(e.target.value)}
                                                    type="text"
                                                    name="name"
                                                    id="name"
                                                    className="border border-gray-300 text-gray-900 rounded-lg focus:ring-violet-500 focus:border-violet-500 block w-full p-2.5 bg-gray-50"
                                                    required
                                                />
                                            </div>
                                            <div>
                                                <label htmlFor="address" className="block mb-2 text-sm font-medium text-gray-700">Full Address</label>
                                                <input
                                                    value={address}
                                                    onChange={(e) => setAddress(e.target.value)}
                                                    type="text"
                                                    name="address"
                                                    id="address"
                                                    className="border border-gray-300 text-gray-900 rounded-lg focus:ring-violet-500 focus:border-violet-500 block w-full p-2.5 bg-gray-50"
                                                    required
                                                />
                                            </div>
                                            <div>
                                                <label htmlFor="pincode" className="block mb-2 text-sm font-medium text-gray-700">Pincode</label>
                                                <input
                                                    value={pincode}
                                                    onChange={(e) => setPincode(e.target.value)}
                                                    type="text"
                                                    name="pincode"
                                                    id="pincode"
                                                    className="border border-gray-300 text-gray-900 rounded-lg focus:ring-violet-500 focus:border-violet-500 block w-full p-2.5 bg-gray-50"
                                                    required
                                                />
                                            </div>
                                            <div>
                                                <label htmlFor="phoneNumber" className="block mb-2 text-sm font-medium text-gray-700">Mobile Number</label>
                                                <input
                                                    value={phoneNumber}
                                                    onChange={(e) => setPhoneNumber(e.target.value)}
                                                    type="text"
                                                    name="phoneNumber"
                                                    id="phoneNumber"
                                                    className="border border-gray-300 text-gray-900 rounded-lg focus:ring-violet-500 focus:border-violet-500 block w-full p-2.5 bg-gray-50"
                                                    required
                                                />
                                            </div>
                                        </form>
                                        <div className="mt-6">
                                            <button
                                                onClick={() => { buyNow(); closeModal(); }}
                                                type="button"
                                                className="w-full text-white bg-gradient-to-r from-purple-500 to-violet-600 hover:from-purple-600 hover:to-violet-700 transition duration-300 font-medium rounded-lg text-sm px-5 py-2.5 shadow-lg"
                                            >
                                                Order Now
                                            </button>
                                        </div>
                                    </div>
                                </Dialog.Panel>
                            </Transition.Child>
                        </div>
                    </div>
                </Dialog>
            </Transition>
        </>
    );
}
