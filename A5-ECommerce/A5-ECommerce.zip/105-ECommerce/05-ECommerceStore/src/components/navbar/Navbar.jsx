import { Fragment, useContext, useState } from 'react';
import { Dialog, Transition } from '@headlessui/react';
import { Link } from 'react-router-dom';
import { BsCart3 } from 'react-icons/bs';
import { MdOutlineNightsStay } from "react-icons/md";
import { FiSun, FiLogOut } from 'react-icons/fi';
import { AiOutlineMenu, AiOutlineOrderedList } from 'react-icons/ai';
import { MdOutlineAdminPanelSettings } from "react-icons/md";
import { RxCross2 } from 'react-icons/rx';
import myContext from '../../context/myContext';
import { TbTruckDelivery } from "react-icons/tb";
import { useSelector } from 'react-redux';
import { RiHomeSmile2Line } from "react-icons/ri";

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const context = useContext(myContext);
  const { toggleMode, mode } = context;
  const user = JSON.parse(localStorage.getItem('user'));

  const logout = () => {
    localStorage.clear('user');
    window.location.href = "/login";
  };

  const cartItems = useSelector((state) => state.cart);

  return (
    <div className={`bg-${mode === 'dark' ? 'gray-900' : 'white'} sticky top-0 z-50 shadow-lg`}>
      {/* Mobile menu */}
      <Transition.Root show={open} as={Fragment}>
        <Dialog as="div" className="relative z-40 lg:hidden" onClose={setOpen}>
          <Transition.Child
            as={Fragment}
            enter="transition-opacity ease-linear duration-300"
            enterFrom="opacity-0"
            enterTo="opacity-100"
            leave="transition-opacity ease-linear duration-300"
            leaveFrom="opacity-100"
            leaveTo="opacity-0"
          >
            <div className="fixed inset-0 bg-black bg-opacity-25" />
          </Transition.Child>

          <div className="fixed inset-0 z-40 flex">
            <Transition.Child
              as={Fragment}
              enter="transition ease-in-out duration-300 transform"
              enterFrom="-translate-x-full"
              enterTo="translate-x-0"
              leave="transition ease-in-out duration-300 transform"
              leaveFrom="translate-x-0"
              leaveTo="-translate-x-full"
            >
              <Dialog.Panel className={`relative flex w-full max-w-xs flex-col overflow-y-auto bg-${mode === 'dark' ? 'gray-800' : 'white'} pb-12 shadow-xl`}>
                <div className="flex px-4 pb-2 pt-28">
                  <button
                    type="button"
                    className="-m-2 inline-flex items-center justify-center rounded-md p-2 text-gray-400"
                    onClick={() => setOpen(false)}
                  >
                    <span className="sr-only hover:text-indigo-600">Close menu</span>
                    <RxCross2 />
                  </button>
                </div>
                <div className="space-y-6 border-t border-gray-200 px-4 py-6">
                  <Link to={'/'} className="flex items-center text-sm font-medium text-gray-900 hover:text-indigo-600" style={{ color: mode === 'dark' ? 'white' : '' }}>
                    <RiHomeSmile2Line className="mr-2" />Home
                  </Link>
                  <Link to={'/allproduct'} className="flex items-center text-sm font-medium text-gray-900 hover:text-indigo-600" style={{ color: mode === 'dark' ? 'white' : '' }}>
                    <AiOutlineOrderedList className="mr-2" /> All Products
                  </Link>
                  <Link to={'/order'} className="flex items-center text-sm font-medium text-gray-900 hover:text-indigo-600" style={{ color: mode === 'dark' ? 'white' : '' }}>
                    <AiOutlineOrderedList className="mr-2" /> Order
                  </Link>
                  {user?.email === 'rejanasim611@gmail.com' && (
                    <Link to={'/dashboard'} className="flex items-center text-sm font-medium text-gray-900 hover:text-indigo-600" style={{ color: mode === 'dark' ? 'white' : '' }}>
                      <MdOutlineAdminPanelSettings className="mr-2" /> Admin
                    </Link>
                  )}
                  {user ? (
                    <div className="flex items-center text-sm font-medium text-gray-900 cursor-pointer hover:text-indigo-600" onClick={logout} style={{ color: mode === 'dark' ? 'white' : '' }}>
                      <FiLogOut className="mr-2" /> Logout
                    </div>
                  ) : (
                    <Link to={'/signup'} className="flex items-center text-sm font-medium text-gray-900 hover:text-indigo-600" style={{ color: mode === 'dark' ? 'white' : '' }}>
                      <FiLogOut className="mr-2" /> Signup
                    </Link>
                  )}
                  <div className="flex items-center text-sm font-medium text-gray-900" style={{ color: mode === 'dark' ? 'white' : '' }}>
                    <img className="inline-block w-10 h-10 rounded-full" src="https://avatars.githubusercontent.com/u/810438?v=4" alt="avatar" />
                  </div>
                </div>
                <div className="border-t border-gray-200 px-4 py-6">
                  <a href="#" className="flex items-center p-2">
                    <img src="https://upload.wikimedia.org/wikipedia/en/thumb/4/41/Flag_of_India.svg/383px-Flag_of_India.svg.png" alt="Flag" className="block h-auto w-5 flex-shrink-0" />
                    <span className="ml-3 block text-base font-medium text-gray-900" style={{ color: mode === 'dark' ? 'white' : '' }}>INDIA</span>
                  </a>
                </div>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </Dialog>
      </Transition.Root>

      {/* Desktop */}
      <header className={`relative bg-${mode === 'dark' ? 'gray-900' : 'white'} shadow-xl`}>
        <p className={`flex h-10 items-center justify-center bg-pink-600 px-4 text-sm font-medium text-white sm:px-6 lg:px-8`} style={{ backgroundColor: mode === 'dark' ? 'rgb(62 64 66)' : '', color: mode === 'dark' ? 'white' : '' ,}}>
          <TbTruckDelivery className="inline mr-1" size={20} /> Get free delivery on orders over ₹50,000
        </p>
        <nav aria-label="Top" className={`bg-${mode === 'dark' ? 'gray-900' : 'gray-100'} px-4 sm:px-6 lg:px-8 shadow-lg`}>
          <div className="flex h-16 items-center">
            <button
              type="button"
              className={`rounded-md p-2 lg:hidden ${mode === 'dark' ? 'bg-gray-700 text-white' : 'bg-white text-gray-400'}`}
              onClick={() => setOpen(true)}
            >
              <span className="sr-only">Open menu</span>
              <AiOutlineMenu size={24} />
            </button>
            {/* Logo */}
            <div className="ml-4 flex lg:ml-0">
              <Link to={'/'} className='flex'>
                <div className="flex items-center">
                  <h1 className={`text-2xl font-bold px-2 py-1 rounded ${mode === 'dark' ? 'text-white' : 'text-black'}`}>E-Bharat</h1>
                </div>
              </Link>
            </div>
            <div className="ml-auto flex items-center">
              <div className="hidden lg:flex lg:items-center lg:justify-end lg:space-x-6">
                <Link to={'/'} className={`text-sm font-medium ${mode === 'dark' ? 'text-white' : 'text-gray-700'} hover:text-indigo-600`}>
                  <RiHomeSmile2Line className="inline mr-1" />Home
                </Link>
                <Link to={'/allproduct'} className={`text-sm font-medium ${mode === 'dark' ? 'text-white' : 'text-gray-700'} hover:text-indigo-600`}>
                  <AiOutlineOrderedList className="inline mr-1" /> All Products
                </Link>
                {user ? <Link to={'/order'} className={`text-sm font-medium ${mode === 'dark' ? 'text-white' : 'text-gray-700'} hover:text-indigo-600`}>
                  <AiOutlineOrderedList className="inline mr-1" /> Order
                </Link> : ""}
                {user?.email === 'rejanasim611@gmail.com' && (
                  <Link to={'/dashboard'} className={`text-sm font-medium ${mode === 'dark' ? 'text-white' : 'text-gray-700'} hover:text-indigo-600`}>
                    <MdOutlineAdminPanelSettings className="inline mr-1" /> Admin
                  </Link>
                )}
                {user ? (
                  <div className={`text-sm font-medium cursor-pointer ${mode === 'dark' ? 'text-white' : 'text-gray-700'} hover:text-indigo-600`} onClick={logout}>
                  <FiLogOut className="inline mr-1" /> Logout</div>) : (
                    <Link to={'/signup'} className={`text-sm font-medium cursor-pointer ${mode === 'dark' ? 'text-white' : 'text-gray-700'} hover:text-indigo-600`}><FiLogOut className="inline mr-1" /> Signup
                    </Link>)}
                  </div>
                              <div className="hidden lg:flex lg:ml-8">
                                <a href="#" className={`flex items-center ${mode === 'dark' ? 'text-white' : 'text-gray-700'} hover:text-indigo-600`}>
                                  <span className="text-sm font-medium">INDIA</span>
                                  <img src="https://upload.wikimedia.org/wikipedia/en/thumb/4/41/Flag_of_India.svg/383px-Flag_of_India.svg.png" alt="Flag" className="ml-2 block h-auto w-5 flex-shrink-0" />
                                </a>
                              </div>
                              {/* Toggle Mode */}
                              <div className="flex lg:ml-6">
                                <button onClick={toggleMode} className="hover:text-indigo-600">
                                  {mode === 'light' ? (
                                    <FiSun size={30} />
                                  ) : (
                                    <MdOutlineNightsStay size={30} style={{ color: mode === 'dark' ? 'white' : '' }} />
                                  )}
                                </button>
                              </div>
                              {/* Cart */}
                              <div className="ml-4 flow-root lg:ml-6">
                                <Link to={'/cart'} className={`group -m-2 flex items-center p-2 ${mode === 'dark' ? 'text-white' : 'text-gray-700'} hover:text-indigo-600`}>
                                  <BsCart3 className='hover:text-pink-600' size={25} />
                                  <span className="ml-2 text-sm font-medium">{cartItems.length}</span>
                                  <span className="sr-only">items in cart, view bag</span>
                                </Link>
                              </div>
                              {/* User Avatar */}
                              <div className="flex items-center ml-4">
                                <img className="inline-block w-10 h-10 rounded-full" src="https://avatars.githubusercontent.com/u/810438?v=4" alt="avatar" />
                              </div>
                            </div>
                          </div>
                        </nav>
                      </header>
                    </div>
                  );
                }
                
