// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";

import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBKw37_4dtku4ceqe334J0uubzHw42j-1Q",
  authDomain: "my-ecommerce-app-edec9.firebaseapp.com",
  projectId: "my-ecommerce-app-edec9",
  storageBucket: "my-ecommerce-app-edec9.appspot.com",
  messagingSenderId: "779044398771",
  appId: "1:779044398771:web:09650cb9d54ee854a832c6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

const fireDB = getFirestore(app);
const auth = getAuth(app)

export {fireDB,auth } ;