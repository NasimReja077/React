import { useContext } from 'react';
import { Link } from 'react-router-dom';
import myContext from '../../context/myContext';
import { FaShippingFast, FaMoneyCheckAlt, FaPhoneAlt, FaEnvelope, FaMapMarkedAlt } from 'react-icons/fa';
import backgroundImage from '../../assets/backgroundImages.jpg';
function ReturnPolicy() {
  const context = useContext(myContext);
  const { mode } = context;

  const bgColor = mode === 'dark' ? 'bg-gray-900' : 'bg-gray-100';
  const textColor = mode === 'dark' ? 'text-white' : 'text-gray-900';
  const sectionBgColor = mode === 'dark' ? 'bg-gray-800' : 'bg-white';
  const borderColor = mode === 'dark' ? 'border-gray-700' : 'border-gray-300';

  return (
    <div className={`min-h-screen ${bgColor} ${textColor} py-10`} style={{ backgroundImage: `url(${backgroundImage})`, backgroundSize: 'cover', backgroundPosition: 'center' }}>
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold mb-10 text-center text-white">Return Policy</h1>

        <div className={`p-6 mb-6 rounded-lg shadow-md ${sectionBgColor} border ${borderColor}`}>
          <h2 className="text-2xl font-semibold mb-4 flex items-center"><FaShippingFast className="mr-3" /> Overview</h2>
          <p className="mb-4">
            At E-Bharat, we are committed to ensuring the satisfaction of our customers. If you are not entirely satisfied with your purchase, we're here to help.
          </p>
          <p className="mb-4">
            Please read our return policy carefully to understand the process and conditions for returning products.
          </p>
        </div>

        <div className={`p-6 mb-6 rounded-lg shadow-md ${sectionBgColor} border ${borderColor}`}>
          <h2 className="text-2xl font-semibold mb-4 flex items-center"><FaMoneyCheckAlt className="mr-3" /> Eligibility for Returns</h2>
          <p className="mb-4">
            To be eligible for a return, your item must be unused and in the same condition that you received it. It must also be in the original packaging.
          </p>
          <p className="mb-4">
            Several types of goods are exempt from being returned, such as perishable goods, custom products, and intimate or sanitary goods.
          </p>
        </div>

        <div className={`p-6 mb-6 rounded-lg shadow-md ${sectionBgColor} border ${borderColor}`}>
          <h2 className="text-2xl font-semibold mb-4 flex items-center"><FaPhoneAlt className="mr-3" /> Return Process</h2>
          <ol className="list-decimal list-inside mb-4">
            <li className="mb-2">Contact our customer service team to initiate a return.</li>
            <li className="mb-2">Receive a return authorization number and shipping instructions.</li>
            <li className="mb-2">Pack the item securely and include the return authorization number.</li>
            <li className="mb-2">Ship the item to the provided address.</li>
          </ol>
          <p className="mb-4">
            Once we receive your return, we will inspect the item and notify you of the status of your refund.
          </p>
        </div>

        <div className={`p-6 mb-6 rounded-lg shadow-md ${sectionBgColor} border ${borderColor}`}>
          <h2 className="text-2xl font-semibold mb-4 flex items-center"><FaMoneyCheckAlt className="mr-3" /> Refunds</h2>
          <p className="mb-4">
            If your return is approved, we will initiate a refund to your original method of payment. You will receive the credit within a certain number of days, depending on your card issuer's policies.
          </p>
        </div>

        <div className={`p-6 mb-6 rounded-lg shadow-md ${sectionBgColor} border ${borderColor}`}>
          <h2 className="text-2xl font-semibold mb-4 flex items-center"><FaEnvelope className="mr-3" /> Contact Us</h2>
          <p className="mb-4">
            If you have any questions about our return policy, please contact us:
          </p>
          <ul className="list-disc list-inside mb-4">
            <li className="mb-2 flex items-center"><FaEnvelope className="mr-3" /> By email: <a href="mailto:support@ebharat.com" className="text-blue-500 hover:underline">support@ebharat.com</a></li>
            <li className="mb-2 flex items-center"><FaPhoneAlt className="mr-3" /> By phone: <a href="tel:+911234567890" className="text-blue-500 hover:underline">+91-123-456-7890</a></li>
            <li className="mb-2 flex items-center"><FaMapMarkedAlt className="mr-3" /> By visiting this page on our website: <Link to="/contact" className="text-blue-500 hover:underline">www.ebharat.com/contact</Link></li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default ReturnPolicy;
