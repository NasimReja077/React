import { useContext } from 'react';
import { Link } from 'react-router-dom';
import myContext from '../../context/myContext';
import { FaUsers, FaHeart, FaLightbulb } from 'react-icons/fa';
import backgroundImage from '../../assets/backgroundImages.jpg';

function About() {
  const context = useContext(myContext);
  const { mode } = context;

  const bgColor = mode === 'dark' ? 'bg-gray-900' : 'bg-gray-100';
  const textColor = mode === 'dark' ? 'text-white' : 'text-gray-900';
  const sectionBgColor = mode === 'dark' ? 'bg-gray-800' : 'bg-white';
  const borderColor = mode === 'dark' ? 'border-gray-700' : 'border-gray-300';

  return (
    <div className={`min-h-screen ${bgColor} ${textColor} py-10`} style={{ backgroundImage: `url(${backgroundImage})`, backgroundSize: 'cover', backgroundPosition: 'center' }}>
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold mb-10 text-center">About Us</h1>

        <div className={`p-6 mb-6 rounded-lg shadow-md ${sectionBgColor} border ${borderColor}`}>
          <h2 className="text-2xl font-semibold mb-4 flex items-center"><FaUsers className="mr-3" /> Our Mission</h2>
          <p className="mb-4">
            At E-Bharat, our mission is to provide the best shopping experience to our customers through innovative technology and excellent customer service.
          </p>
          <p className="mb-4">
            We aim to connect local sellers with consumers across the country, promoting local businesses and products.
          </p>
        </div>

        <div className={`p-6 mb-6 rounded-lg shadow-md ${sectionBgColor} border ${borderColor}`}>
          <h2 className="text-2xl font-semibold mb-4 flex items-center"><FaHeart className="mr-3" /> Our Values</h2>
          <p className="mb-4">
            <strong>Customer Satisfaction:</strong> We prioritize customer needs and strive to exceed their expectations.
          </p>
          <p className="mb-4">
            <strong>Quality and Diversity:</strong> We offer a wide range of products from trusted sellers, ensuring quality and variety.
          </p>
          <p className="mb-4">
            <strong>Sustainability:</strong> We support sustainable practices and products that benefit our planet and communities.
          </p>
        </div>

        <div className={`p-6 mb-6 rounded-lg shadow-md ${sectionBgColor} border ${borderColor}`}>
          <h2 className="text-2xl font-semibold mb-4 flex items-center"><FaLightbulb className="mr-3" /> Our Vision</h2>
          <p className="mb-4">
            Our vision is to become the leading e-commerce platform that empowers local sellers and provides customers with a seamless shopping experience.
          </p>
          <p className="mb-4">
            We strive to innovate continuously, embracing new technologies and customer-centric solutions.
          </p>
        </div>

        <div className="text-center">
          <Link to="/contact" className="inline-block bg-blue-500 hover:bg-blue-600 text-white py-3 px-6 rounded-md transition duration-300">Contact Us</Link>
        </div>
      </div>
    </div>
  );
}

export default About;
