import React, { useContext } from 'react';
import { FaShoppingBag, FaClipboardList, FaUserFriends } from 'react-icons/fa';
import myContext from '../../../context/myContext';
import Layout from '../../../components/layout/Layout';
import DashboardTab from './DashboardTab';

function Dashboard() {
  const context = useContext(myContext);
  const { mode } = context;

  const cardBgColor = mode === 'dark' ? 'bg-gray-800 text-white' : 'bg-white text-gray-900';
  const borderColor = mode === 'dark' ? 'border-gray-700' : 'border-gray-200';
  const shadowColor = mode === 'dark' ? 'shadow-gray-700' : 'shadow-gray-300';
  const iconBgColor = mode === 'dark' ? 'bg-purple-600' : 'bg-purple-100';
  const iconColor = mode === 'dark' ? 'text-purple-200' : 'text-purple-600';

  return (
    <Layout>
      <section className="text-gray-600 body-font mt-10 mb-10">
        <div className="container px-5 mx-auto mb-10">
          <div className="flex flex-wrap -m-4 text-center justify-center">
            <div className="p-4 md:w-1/4 sm:w-1/2 w-full">
              <div
                className={`border-2 ${borderColor} ${shadowColor} ${cardBgColor} px-6 py-6 rounded-xl transition-all duration-300 ease-in-out transform hover:scale-105 hover:shadow-lg`}
              >
                <div className={`w-12 h-12 mb-3 inline-flex items-center justify-center rounded-full ${iconBgColor}`}>
                  <FaShoppingBag size={32} className={iconColor} />
                </div>
                <h2 className="title-font font-medium text-3xl">{'10'}</h2>
                <p className="text-purple-500 font-bold">{'Total Products'}</p>
              </div>
            </div>
            <div className="p-4 md:w-1/4 sm:w-1/2 w-full">
              <div
                className={`border-2 ${borderColor} ${shadowColor} ${cardBgColor} px-6 py-6 rounded-xl transition-all duration-300 ease-in-out transform hover:scale-105 hover:shadow-lg`}
              >
                <div className={`w-12 h-12 mb-3 inline-flex items-center justify-center rounded-full ${iconBgColor}`}>
                  <FaClipboardList size={32} className={iconColor} />
                </div>
                <h2 className="title-font font-medium text-3xl">{'10'}</h2>
                <p className="text-purple-500 font-bold">{'Total Orders'}</p>
              </div>
            </div>
            <div className="p-4 md:w-1/4 sm:w-1/2 w-full">
              <div
                className={`border-2 ${borderColor} ${shadowColor} ${cardBgColor} px-6 py-6 rounded-xl transition-all duration-300 ease-in-out transform hover:scale-105 hover:shadow-lg`}
              >
                <div className={`w-12 h-12 mb-3 inline-flex items-center justify-center rounded-full ${iconBgColor}`}>
                  <FaUserFriends size={32} className={iconColor} />
                </div>
                <h2 className="title-font font-medium text-3xl">{'20'}</h2>
                <p className="text-purple-500 font-bold">{'Total Users'}</p>
              </div>
            </div>
          </div>
        </div>
      </section>
      <DashboardTab />
    </Layout>
  );
}

export default Dashboard;
