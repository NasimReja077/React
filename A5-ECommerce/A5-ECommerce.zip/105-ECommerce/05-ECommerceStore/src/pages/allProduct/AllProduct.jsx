import React, { useContext, useEffect } from 'react'
import Filter from '../../components/filter/Filter'
import ProductCard from '../../components/ProductCard/ProductCard'
import Layout from '../../components/layout/Layout'
import myContext from '../../context/myContext'
import { useDispatch, useSelector } from 'react-redux'
import { addToCart } from '../../redux/cartSlice'
import { FiShoppingCart } from 'react-icons/fi';
import { toast } from 'react-toastify';

function AllProduct() {
  const context = useContext(myContext)
  const { mode, product ,searchkey, setSearchkey,filterType,setFilterType,filterPrice,setFilterPrice} = context

  const dispatch = useDispatch()
  const cartItems = useSelector((state)=> state.cart);//   console.log(cartItems)
  
  const addCart = (product) => {
    dispatch(addToCart(product));
    toast.success('Added to Cart!');
  };

  useEffect(() => {
      localStorage.setItem('cart', JSON.stringify(cartItems));
  }, [cartItems])
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  const cardBgColor = mode === 'dark' ? '#2e3137' : '#ffffff';
  const textColor = mode === 'dark' ? '#ffffff' : '#000000';
  const borderColor = mode === 'dark' ? '#3f4349' : '#e2e8f0';
  const hoverShadowColor = mode === 'dark' ? 'rgba(255, 255, 255, 0.2)' : 'rgba(0, 0, 0, 0.1)';

  return (
    <Layout>
      <Filter/>
      <section className="text-gray-600 body-font">
      <div className="container px-5 py-8 md:py-16 mx-auto">
        <div className="lg:w-1/2 w-full mb-6 lg:mb-10">
          <h1 className="sm:text-3xl text-2xl font-medium title-font mb-2" style={{ color: textColor }}>
            Our Latest Collection
          </h1>
          <div className="h-1 w-20 bg-gradient-to-r from-pink-500 to-purple-500 rounded"></div>
        </div>

        <div className="flex flex-wrap -m-4">
          {product
            .filter((obj) => obj.title.toLowerCase().includes(searchkey))
            .filter((obj) => obj.category.toLowerCase().includes(filterType))
            // .filter((obj) => obj.price.toString().includes(filterPrice))
            // .slice(0, 8)
            .map((item, index) => {
              const { title, price, imageUrl, id } = item;
              return (
                <div key={id || index} className="p-4 md:w-1/2 lg:w-1/3 xl:w-1/4">
                  <div
                    className="h-full border-2 hover:shadow-2xl transition-shadow duration-300 ease-in-out border-opacity-60 rounded-2xl overflow-hidden"
                    style={{ backgroundColor: cardBgColor, color: textColor, borderColor }}
                  >
                    <div
                      className="flex justify-center cursor-pointer"
                      onClick={() => window.location.href = `/productinfo/${id}`}
                    >
                      <img
                        className="rounded-t-2xl w-full h-80 p-2 hover:scale-105 transition-transform duration-300 ease-in-out"
                        src={imageUrl}
                        alt="product"
                      />
                    </div>
                    <div className="p-5 border-t-2" style={{ borderColor }}>
                      <h2 className="tracking-widest text-xs title-font font-medium mb-1" style={{ color: textColor }}>
                        E-Bharat
                      </h2>
                      <h1 className="title-font text-lg font-medium mb-3" style={{ color: textColor }}>
                        {title}
                      </h1>
                      <div className="flex justify-between items-center">
                        <p className="leading-relaxed mb-3" style={{ color: textColor }}>
                          ₹{price}
                        </p>
                        <button
                          onClick={(e) => { e.stopPropagation(); addCart(item); }}
                          type="button"
                          className="flex items-center focus:outline-none text-white bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 focus:ring-4 focus:ring-purple-300 font-medium rounded-lg text-sm py-2 px-4 transition-all duration-300"
                        >
                          <FiShoppingCart className="mr-2" /> Add To Cart
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
        </div>
      </div>
    </section>
    </Layout>
  )
}

export default AllProduct