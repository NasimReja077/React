import React, { useContext, useEffect, useState } from 'react';
import myContext from '../../context/myContext';
import Layout from '../../components/layout/Layout';
import Modal from '../../components/modal/Modal';
import { useDispatch, useSelector } from 'react-redux';
import { deleteFromCart } from '../../redux/cartSlice';
import { toast } from 'react-toastify';
import { addDoc, collection } from 'firebase/firestore';
import { fireDB } from '../../firebase/FirebaseConfig';
import { AiOutlineDelete } from 'react-icons/ai';

function CartPage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const context = useContext(myContext);
  const { mode } = context;
  const dispatch = useDispatch();
  const cartItems = useSelector((state) => state.cart);

  const deleteCart = (item) => {
    dispatch(deleteFromCart(item));
    toast.success('Item removed from cart');
  };

  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cartItems));
  }, [cartItems]);

  const [totalAmout, setTotalAmount] = useState(0);
  useEffect(() => {
    let temp = 0;
    cartItems.forEach((item) => {
      temp += parseInt(item.price);
    });
    setTotalAmount(temp);
  }, [cartItems]);

  const shipping = 100;
  const grandTotal = shipping + totalAmout;

  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [pincode, setPincode] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');

  const buyNow = async () => {
    if (name === '' || address === '' || pincode === '' || phoneNumber === '') {
      return toast.error('All fields are required', {
        position: 'top-center',
        autoClose: 1000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: 'colored',
      });
    }
    const addressInfo = {
      name,
      address,
      pincode,
      phoneNumber,
      date: new Date().toLocaleString('en-US', {
        month: 'short',
        day: '2-digit',
        year: 'numeric',
      }),
    };

    var options = {
      key: 'rzp_test_TG7HmjgowS8hHc',
      key_secret: 'rQYZVGItXxKvYM4o4qVyrS9O',
      amount: grandTotal * 100,
      currency: 'INR',
      order_receipt: 'order_rcptid_' + name,
      name: 'E-Bharat',
      description: 'for testing purpose',
      handler: async function (response) {
        toast.success('Payment Successful');

        const paymentId = response.razorpay_payment_id;

        const orderInfo = {
          cartItems,
          addressInfo,
          date: new Date().toLocaleString('en-US', {
            month: 'short',
            day: '2-digit',
            year: 'numeric',
          }),
          email: JSON.parse(localStorage.getItem('user')).user.email,
          userid: JSON.parse(localStorage.getItem('user')).user.uid,
          paymentId,
        };
        try {
          const orderRef = collection(fireDB, 'order');
          await addDoc(orderRef, orderInfo);
          toast.success('Order placed successfully!');
        } catch (error) {
          toast.error('Error placing order');
        }
      },
      theme: {
        color: '#3399cc',
      },
    };
    var pay = new window.Razorpay(options);
    pay.open();
  };

  return (
    <Layout>
      <div
        className={`h-full pt-5 mb-[60%] ${mode === 'dark' ? 'bg-gray-800 text-white' : 'bg-gray-100 text-gray-900'}`}
      >
        <h1 className="mb-10 text-center text-2xl font-bold">Cart Items</h1>
        <div className="mx-auto max-w-5xl justify-center px-6 md:flex md:space-x-6 xl:px-0">
          <div className="rounded-lg md:w-2/3">
            {cartItems.map((item, index) => {
              const { title, price, description, imageUrl } = item;
              return (
                <div
                  key={index}
                  className={`justify-between mb-6 rounded-lg border drop-shadow-xl bg-white p-6 sm:flex sm:justify-start transition-all duration-200 hover:shadow-lg ${
                    mode === 'dark' ? 'bg-gray-700' : ''
                  }`}
                  style={{ backgroundColor: mode === 'dark' ? 'rgb(32 33 34)' : '', color: mode === 'dark' ? 'white' : '', }}
                >
                  <img src={imageUrl} alt="product-image" className="w-full rounded-lg sm:w-40" />
                  <div className="sm:ml-4 sm:flex sm:w-full sm:justify-between">
                    <div className="mt-5 sm:mt-0">
                      <h2 className="text-lg font-bold" style={{ color: mode === 'dark' ? 'white' : '' }}>
                        {title}
                      </h2>
                      <h2 className="text-sm" style={{ color: mode === 'dark' ? 'white' : '' }}>
                        {description}
                      </h2>
                      <p className="mt-1 text-xs font-semibold" style={{ color: mode === 'dark' ? 'white' : '' }}>
                        ₹{price}
                      </p>
                    </div>
                    <div
                      onClick={() => deleteCart(item)}
                      className="mt-4 flex justify-between sm:space-y-6 sm:mt-0 sm:block sm:space-x-6 cursor-pointer transition-all duration-200 hover:text-red-500"
                    >
                      <AiOutlineDelete className="w-6 h-6" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div
            className={`mt-6 h-full rounded-lg border p-6 shadow-md md:mt-0 md:w-1/3 ${
              mode === 'dark' ? 'bg-gray-700' : 'bg-white'
            }`}
          >
            <div className="mb-2 flex justify-between">
              <p className="text-gray-700" style={{ color: mode === 'dark' ? 'white' : '' }}>
                Subtotal
              </p>
              <p className="text-gray-700" style={{ color: mode === 'dark' ? 'white' : '' }}>
                ₹{totalAmout}
              </p>
            </div>
            <div className="flex justify-between">
              <p className="text-gray-700" style={{ color: mode === 'dark' ? 'white' : '' }}>
                Shipping
              </p>
              <p className="text-gray-700" style={{ color: mode === 'dark' ? 'white' : '' }}>
                ₹{shipping}
              </p>
            </div>
            <hr className="my-4" />
            <div className="flex justify-between mb-3">
              <p className="text-lg font-bold" style={{ color: mode === 'dark' ? 'white' : '' }}>
                Total
              </p>
              <div>
                <p className="mb-1 text-lg font-bold" style={{ color: mode === 'dark' ? 'white' : '' }}>
                  ₹{grandTotal}
                </p>
              </div>
            </div>
            <Modal
              name={name}
              address={address}
              pincode={pincode}
              phoneNumber={phoneNumber}
              setName={setName}
              setAddress={setAddress}
              setPincode={setPincode}
              setPhoneNumber={setPhoneNumber}
              buyNow={buyNow}
            />
          </div>
        </div>
      </div>
    </Layout>
  );
}

export default CartPage;
