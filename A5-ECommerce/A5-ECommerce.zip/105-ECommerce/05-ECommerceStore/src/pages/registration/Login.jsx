import { Link, useNavigate } from 'react-router-dom';
import { useContext, useState } from 'react';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../../firebase/FirebaseConfig';
import { toast } from 'react-toastify';
import myContext from '../../context/myContext';
import Loader from '../../components/loader/Loader';
import { AiOutlineMail, AiOutlineLock } from 'react-icons/ai';

function Login() {
    const context = useContext(myContext);
    const { loading, setLoading } = context;

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const navigate = useNavigate();

    const signin = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            const result = await signInWithEmailAndPassword(auth, email, password);
            toast.success("Login Successful", {
                position: "top-right",
                autoClose: 2000,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "colored",
            });
            localStorage.setItem('user', JSON.stringify(result.user));
            navigate('/');
        } catch (error) {
            console.error("Login Error:", error);
            toast.error("Login Failed: " + error.message, {
                position: "top-right",
                autoClose: 2000,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "colored",
            });
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="flex justify-center items-center h-screen bg-gray-900">
            {loading && <Loader />}
            <div className="bg-gray-800 px-10 py-10 rounded-xl w-full max-w-md transform transition-transform hover:scale-105">
                <h1 className="text-center text-white text-3xl mb-4 font-bold">Login</h1>
                <form className="space-y-4" onSubmit={signin}>
                    <div className="relative">
                        <AiOutlineMail className="absolute left-3 top-3 text-gray-400" />
                        <input
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            name="email"
                            className="bg-gray-600 mb-4 px-10 py-2 w-full rounded-lg text-white placeholder-gray-200 outline-none"
                            placeholder="Email"
                        />
                    </div>
                    <div className="relative">
                        <AiOutlineLock className="absolute left-3 top-3 text-gray-400" />
                        <input
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="bg-gray-600 mb-4 px-10 py-2 w-full rounded-lg text-white placeholder-gray-200 outline-none"
                            placeholder="Password"
                        />
                    </div>
                    <div className="flex justify-center">
                        <button type="submit" className="bg-yellow-500 w-full text-black font-bold px-4 py-2 rounded-lg hover:bg-yellow-600 transition-colors duration-300">
                            Login
                        </button>
                    </div>
                    <div className="text-center">
                        <span className="text-white">Don't have an account? </span>
                        <Link className="text-yellow-500 font-bold hover:underline" to="/signup">
                            Signup
                        </Link>
                    </div>
                </form>
            </div>
        </div>
    );
}

export default Login;
