import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/home/Home';
import AllMovies from './pages/allMovies/AllMovies';
import AddMovie from './pages/admin/adPages/AddMovie';
import UpdateMovie from './pages/admin/adPages/UpdateMovie';
import Dashboard from './pages/admin/dashboard/Dashboard';
import MyBookingInfo from './pages/moviesInfo/MovieInfo';
import MovieInfo from './pages/moviesInfo/MovieInfo';
import NoPages from './pages/noPages/NoPages';
import PayCart from './pages/payCart/PayCart';
import Login from './pages/registration/login/Login';
import Signup from './pages/registration/signup/Signup';
import SeatBooking from './pages/seatBooking/SeatBookig';
import UserProfile from './pages/userProfile/UserProfile';
import MyState from './context/MyState';
import VideoPlayer from './components/videoplayer/VideoPlayer'
import MovieCard from './components/movieCard/MovieCard';
import ScrollTop from './components/scrollTop/ScrollTop';

// import { ToastContainer } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';

function App() {

  return (
    <MyState>
      <Router>
        <ScrollTop />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/allmovies" element={<AllMovies />} />
          <Route path="/addmovie" element={<AddMovie />} />
          <Route path="/updatemovie" element={<UpdateMovie />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/mybookinginfo/" element={<MyBookingInfo />} />
          <Route path="/movieinfo" element={<MovieInfo />} />
          <Route path="/*" element={<NoPages />} />
          <Route path="/paycart" element={<PayCart />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/seatbooking" element={<SeatBooking />} />
          <Route path="/userprofile" element={<UserProfile />} />
          <Route path="/player" element={<VideoPlayer />} />
          <Route path='/moviecard' element={<MovieCard />} />
          
        </Routes>
        {/* <ToastContainer /> */}
      </Router>
    </MyState>
  );
}

export default App;
