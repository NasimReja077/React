import React from 'react';
import { FaFacebookF, FaTwitter, FaInstagram, FaLinkedinIn, FaGithub, FaTwitch } from 'react-icons/fa';
import { Link } from 'react-router-dom';
import backgroundImage from '../../assets/footer.jpg';

const Footer = () => {
  const sections = [
    {
      title: "Categories",
      items: ["Home", "MyBookingInfo", "Cart", "MovieInfo"],
    },
    {
      title: "Customer Service",
      items: ["Return Policy", "About", "Contact Us"],
    },
    {
      title: "Services",
      items: ["Privacy"],
    },
  ];

  const socialMediaItems = [
    { name: "Facebook", icon: FaFacebookF, link: "https://www.facebook.com/" },
    { name: "Instagram", icon: FaInstagram, link: "https://www.instagram.com/" },
    { name: "Twitter", icon: FaTwitter, link: "https://twitter.com/" },
    { name: "LinkedIn", icon: FaLinkedinIn, link: "https://linkedin.com/" },
    { name: "Github", icon: FaGithub, link: "https://github.com/" },
    { name: "Twitch", icon: FaTwitch, link: "https://www.twitch.tv/" },
  ];

  return (
    <footer
      className="relative text-gray-600 body-font bg-cover bg-center bg-no-repeat"
      style={{ backgroundImage: `url(${backgroundImage})`, backdropFilter: 'blur(10px)' }}
    >
      <div className="bg-black bg-opacity-70 py-12">
        <div className="container px-5 mx-auto">
          <div className="flex flex-wrap md:text-left text-center justify-between">
            {/* Sections */}
            {sections.map((section, index) => (
              <div key={index} className="lg:w-1/4 md:w-1/2 w-full px-4 mb-10">
                <h2 className="title-font font-semibold text-lg mb-3 text-white">{section.title}</h2>
                <nav className="list-none">
                  {section.items.map((item) => (
                    <li className="mb-2" key={item}>
                      <Link
                        className="hover:text-gray-300 transition duration-300"
                        to={`/${item.toLowerCase().replace(/ /g, '')}`}
                      >
                        {item}
                      </Link>
                    </li>
                  ))}
                </nav>
              </div>
            ))}
            {/* Email Subscription */}
            <div className="w-full md:w-1/4 mb-10">
              <h2 className="title-font font-semibold text-lg mb-3 text-white">Subscribe</h2>
              <div className="flex items-center justify-center md:justify-end">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="px-4 py-2 w-48 rounded-l-md focus:outline-none"
                />
                <button className="bg-red-500 text-white px-4 py-2 rounded-r-md hover:bg-red-600 transition duration-300">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="bg-gray-800 py-4">
        <div className="container mx-auto flex flex-col items-center md:flex-row justify-between">
          <p className="text-sm text-white">
            © {new Date().getFullYear()} E-Bharat —
            <a href="https://www.ebharat.com" rel="noopener noreferrer" target="_blank" className="ml-1 text-gray-400 hover:text-gray-300 transition duration-300">
              www.ebharat.com
            </a>
          </p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            {socialMediaItems.map((item, index) => (
              <a key={index} href={item.link} className="text-white hover:text-gray-400 transition duration-300">
                <item.icon className="w-5 h-5" />
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
