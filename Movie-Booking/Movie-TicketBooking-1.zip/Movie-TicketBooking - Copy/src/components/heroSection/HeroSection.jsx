import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { HiChevronLeft, HiChevronRight } from "react-icons/hi2";
import { FaStar, FaPlay, FaTicketAlt } from "react-icons/fa";

const screenWidth = window.innerWidth;

const Slider = () => {
  const [movieList, setMovieList] = useState([]);
  const elementRef = useRef();
  const navigate = useNavigate();

  useEffect(() => {
    getTrendingMovies();
  }, []);

  const getTrendingMovies = () => {
    const movies = [
      {
        id: 1,
        backdrop_path: "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/bf853092-d54d-4bd0-842b-1facd2b89c32/def70lw-b59d64f0-12b4-43df-a315-6c1d5b553419.png/v1/fill/w_1317,h_607,q_70,strp/spider_man__no_way_home__horizontal_subway__poster_by_iwasboredsoididthis_def70lw-pre.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9ODg1IiwicGF0aCI6IlwvZlwvYmY4NTMwOTItZDU0ZC00YmQwLTg0MmItMWZhY2QyYjg5YzMyXC9kZWY3MGx3LWI1OWQ2NGYwLTEyYjQtNDNkZi1hMzE1LTZjMWQ1YjU1MzQxOS5wbmciLCJ3aWR0aCI6Ijw9MTkyMCJ9XV0sImF1ZCI6WyJ1cm46c2VydmljZTppbWFnZS5vcGVyYXRpb25zIl19.Uy1bGezdnUIoAS9SXJgO3FeWr0tvzktfURJYDCfCxMo",
        title: "Spider-Man: No Way Home",
        rating: 8.7,
        video_url: "https://www.youtube.com/watch?v=JfVOs4VSpmA",
        description: "Spider-Man: No Way Home is a 2021 superhero film based on the Marvel Comics character Spider-Man."
      },
      {
        id: 2,
        backdrop_path: "https://i3.wp.com/m.media-amazon.com/images/I/71hzHbySzDL.jpg?ssl=1",
        title: "Avengers: Endgame",
        rating: 9.0,
        video_url: "https://www.youtube.com/watch?v=TcMBFSGVi1c",
        description: "Avengers: Endgame is a 2019 superhero film based on the Marvel Comics superhero team the Avengers."
      },
      {
        id: 3,
        backdrop_path: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRTyVeVoCErjLNLIL2PvI38jUftWAnKCtuQFvGnXrnOGb4gk0CVcaZkCkaCWUd5PMtOoA4&usqp=CAU",
        title: "Inception",
        rating: 8.8,
        video_url: "https://www.youtube.com/watch?v=YoHD9XEInc0",
        description: "Inception is a 2010 science fiction action film written and directed by Christopher Nolan."
      },
      // Add more movie objects as needed
    ];
    setMovieList(movies);
  };

  const sliderRight = (element) => {
    element.scrollLeft += screenWidth - 110;
  };

  const sliderLeft = (element) => {
    element.scrollLeft -= screenWidth - 110;
  };

  const handleTrailerClick = (movie) => {
    navigate("/player", { state: movie });
  };

  return (
    <div className="relative">
      <HiChevronLeft
        className="hidden md:block text-white text-[30px] absolute left-0 top-1/2 transform -translate-y-1/2 cursor-pointer z-10"
        onClick={() => sliderLeft(elementRef.current)}
      />
      <HiChevronRight
        className="hidden md:block text-white text-[30px] absolute right-0 top-1/2 transform -translate-y-1/2 cursor-pointer z-10"
        onClick={() => sliderRight(elementRef.current)}
      />
      <div
        className="flex overflow-x-auto w-full px-16 py-4 scrollbar-hide md:scrollbar-default scroll-smooth"
        ref={elementRef}
      >
        {movieList.map((item) => (
          <div
            key={item.id}
            className="relative min-w-full md:h-[310px] mr-5 rounded-md overflow-hidden hover:border-[4px] border-gray-400 transition-all duration-100 ease-in"
          >
            <img
              src={item.backdrop_path}
              alt={item.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4">
              <h2 className="text-white font-bold">{item.title}</h2>
              <div className="flex items-center text-yellow-500">
                <FaStar className="mr-1" /> {item.rating}
              </div>
              <div className="flex mt-2 space-x-2">
                <button className="bg-red-500 text-white px-3 py-1 rounded-md flex items-center hover:bg-red-600 transition duration-300">
                  <FaTicketAlt className="mr-2" /> Book Now
                </button>
                <button
                  className="bg-blue-500 text-white px-3 py-1 rounded-md flex items-center hover:bg-blue-600 transition duration-300"
                  onClick={() => handleTrailerClick(item)}
                >
                  <FaPlay className="mr-2" /> Trailer
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Slider;
