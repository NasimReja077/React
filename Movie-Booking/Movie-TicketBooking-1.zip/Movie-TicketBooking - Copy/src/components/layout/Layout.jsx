import React from 'react';
import Footer from '../footer/Footer'
import Navebar from '../nav/Navebar';


const Layout = ({ children }) => {
    return (
        <div>
            <Navebar/>
            <div className="main-content">
                {children}
            </div>
            <Footer />
        </div>
    );
}

export default Layout;
