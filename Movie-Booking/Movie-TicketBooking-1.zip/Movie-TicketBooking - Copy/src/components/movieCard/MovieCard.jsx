import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import myContext from '../../context/myContext';
import { FaStar, FaPlay, FaTicketAlt, FaCalendarAlt, FaFilm } from 'react-icons/fa';

function MovieCard() {
    const context = useContext(myContext);
    const { mode } = context;
    const navigate = useNavigate(); 

    const cardBgColor = mode === 'dark' ? '#2e3137' : '#ffffff';
    const textColor = mode === 'dark' ? '#ffffff' : '#000000';
    const borderColor = mode === 'dark' ? '#3f4349' : '#e2e8f0';

    function handleTrailerClick(movie) {
        navigate('/player', { state: movie });
    }

    const movie = {
        video_url: 'https://youtu.be/pwsh4FjLavU',
        title: 'Movie Title',
        release_date: '12/5/25',
        description: 'Sample description',
        studio: 'Studio Name',
        rating: '8.6',
        genres: ['Genre1', 'Genre2', 'Genre3']
    };

    return (
        <section className="text-gray-600 body-font">
            <div className="container px-5 py-8 md:py-16 mx-auto">
                <div className="lg:w-1/2 w-full mb-6 lg:mb-10">
                    <h1 className="sm:text-3xl text-2xl font-medium title-font mb-2" style={{ color: textColor }}>
                        Our Latest Movies Collection
                    </h1>
                    <div className="h-1 w-20 bg-gradient-to-r from-pink-500 to-purple-500 rounded"></div>
                </div>
                <div className="flex flex-wrap -m-4">
                    <div className="p-4 md:w-1/2 lg:w-1/3 xl:w-1/4">
                        <div className="relative h-full border-2 hover:shadow-2xl transition-shadow duration-300 ease-in-out border-opacity-60 rounded-2xl overflow-hidden"
                            style={{ backgroundColor: cardBgColor, color: textColor, borderColor }}>
                            
                            <div className="relative cursor-pointer overflow-hidden group">
                                <img

                                onClick={() => navigate('/movieinfo')}
                                className="rounded-t-2xl w-full h-96 object-cover group-hover:brightness-50 transition-all duration-300 ease-in-out"
                                    src={'https://cdn.marvel.com/u/prod/marvel/i/mg/6/30/6615419f2a2be/portrait_uncanny.jpg'}
                                    alt="Movie1"
                                />
                                <div className="absolute top-2 left-2 bg-gray-800 bg-opacity-75 text-white text-xs font-semibold px-2 py-1 rounded flex items-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                                    <FaStar className="mr-1" />
                                    8.6
                                </div>
                                <div className="absolute top-2 right-2 bg-gray-800 bg-opacity-75 text-white text-xs font-semibold px-2 py-1 rounded flex items-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                                    <FaCalendarAlt className="mr-1" />
                                    12/5/25
                                </div>
                                <div className="absolute bottom-0 w-full flex justify-center items-center pb-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                                    <div className="flex space-x-2">
                                        {movie.genres.map((genre, index) => (
                                            <h2 key={index} className="px-4 py-2 text-xs rounded-full text-white border border-indigo-500 tracking-widest title-font font-medium">
                                                {genre}
                                            </h2>
                                        ))}
                                    </div>
                                </div>
                            </div>
                            <div className="p-5 border-t-2" style={{ borderColor }}>
                                <h1 className="title-font text-lg mb-3 font-bold" style={{ color: textColor }}>
                                    Movie Title
                                </h1>
                                <div className="flex items-center mb-3 text-sm text-gray-500">
                                    <FaFilm className="mr-1" /> Studio Name
                                </div>
                                <div className="flex justify-center mt-2 space-x-2">
                                    <button className="bg-gradient-to-r from-pink-500 to-purple-500 text-white px-4 py-2 rounded-md flex items-center hover:from-pink-600 hover:to-purple-600 transition duration-300">
                                        <FaTicketAlt className="mr-2" /> Book Now
                                    </button>
                                    <button
                                        className="bg-blue-500 text-white px-4 py-2 rounded-md flex items-center hover:bg-blue-600 transition duration-300"
                                        onClick={() => handleTrailerClick(movie)} // Pass the movie object
                                    >
                                        <FaPlay className="mr-2" /> Trailer
                                    </button>
                                </div>

                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>  
        </section>
    );
}

export default MovieCard;
