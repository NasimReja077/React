import React, { useContext } from 'react';
import MyContext from '../../context/myContext';
import { FaStar, FaCalendarAlt } from 'react-icons/fa';

const MovieCard = ({ movie }) => {
  // Check if the movie prop is available
  if (!movie) {
    return <div>Movie data is not available</div>;
  }

  const { mode } = useContext(MyContext);
  const cardBgColor = mode === 'dark' ? '#2e3137' : '#ffffff';
  const textColor = mode === 'dark' ? '#ffffff' : '#000000';
  const borderColor = mode === 'dark' ? '#3f4349' : '#e2e8f0';
  const hoverShadowColor = mode === 'dark' ? 'rgba(255, 255, 255, 0.2)' : 'rgba(0, 0, 0, 0.1)';

  return (
    <div 
      className="relative border rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300"
      style={{ backgroundColor: cardBgColor, borderColor: borderColor, color: textColor }}
    >
      <img 
        src={movie.image} 
        alt={movie.title} 
        className="w-full h-60 object-cover hover:scale-105 transition-transform duration-300" 
      />
      <div className="absolute top-2 left-2 bg-gray-800 text-white text-xs font-semibold px-2 py-1 rounded flex items-center">
        <FaStar className="mr-1" />
        {movie.rating}
      </div>
      <div className="absolute top-2 right-2 bg-gray-800 text-white text-xs font-semibold px-2 py-1 rounded flex items-center">
        <FaCalendarAlt className="mr-1" />
        {movie.releaseDate}
      </div>
      <div className="p-4">
        <h3 className="text-xl font-bold mb-2">{movie.title}</h3>
        <p className="text-gray-600 dark:text-gray-400">{movie.genres}</p>
        <div className="flex justify-between mt-4">
          <button className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition-colors duration-300">
            Book Now
          </button>
          <button className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition-colors duration-300">
            Trailer
          </button>
        </div>
      </div>
    </div>
  );
};

export default MovieCard;
