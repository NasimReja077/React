import React from 'react';
import MovieCard from './MovieCard2';

const movies = [
  {
    id: 1,
    image: 'https://images2.alphacoders.com/135/thumbbig-1358046.webp',
    title: 'Movie Title 1',
    genres: 'Action, Adventure',
    releaseDate: '2024-01-01',
    rating: 8.5
  },
  {
    id: 2,
    image: 'https://cdn.marvel.com/u/prod/marvel/i/mg/6/60/65d73a84035cd/portrait_uncanny.jpg',
    title: 'Movie Title 2',
    genres: 'Action, Sci-Fi',
    releaseDate: '2024-02-15',
    rating: 7.8
  },
  {
    id: 3,
    image: 'https://cdn.marvel.com/u/prod/marvel/i/mg/6/30/6615419f2a2be/portrait_uncanny.jpg',
    title: 'Movie Title 3',
    genres: 'Drama, Romance',
    releaseDate: '2023-12-20',
    rating: 9.2
  },
  {
    id: 4,
    image: 'https://cdn.marvel.com/u/prod/marvel/i/mg/3/20/66154166e2bc2/portrait_uncanny.jpg',
    title: 'Movie Title 4',
    genres: 'Horror, Thriller',
    releaseDate: '2024-03-05',
    rating: 6.5
  },
  {
    id: 5,
    image: 'https://static.dc.com/2023-12/Movies_Thumb_AquamanTheLostKingdom_1222.jpg?w=640',
    title: 'Movie Title 5',
    genres: 'Fantasy, Action',
    releaseDate: '2024-06-12',
    rating: 7.0
  },
  {
    id: 6,
    image: 'https://static.dc.com/2023-05/Movies_Thumb_TheFlash.jpg?w=640',
    title: 'Movie Title 6',
    genres: 'Action, Adventure',
    releaseDate: '2024-04-25',
    rating: 8.0
  }
];

const MovieList = () => {
     return (
       <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
         {movies.map(movie => (
           <MovieCard key={movie.id} movie={movie} />
         ))}
       </div>
     );
   };
   

export default MovieList;
