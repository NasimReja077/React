import { Fragment, useContext, useState } from 'react';
import { Dialog, Transition } from '@headlessui/react';
import { Link, useLocation } from 'react-router-dom';
import { MdOutlineNightsStay } from "react-icons/md";
import { FiSun, FiLogOut } from 'react-icons/fi';
import { AiOutlineMenu } from 'react-icons/ai';
import { MdOutlineAdminPanelSettings } from "react-icons/md";
import { RxCross2 } from 'react-icons/rx';
import myContext from '../../context/myContext';
import { TbBrandGoogleHome } from "react-icons/tb";
import { BiMoviePlay } from "react-icons/bi";
import { MdBookOnline } from "react-icons/md";
import { CgProfile } from "react-icons/cg";
import { CgLogOut } from "react-icons/cg";
import { GiTicket } from "react-icons/gi"; 
import Logo from '../../assets/Logo1.png';

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  const context = useContext(myContext);
  const { toggleMode, mode } = context;
  const user = JSON.parse(localStorage.getItem('user'));

  return (
    <div className={`bg-${mode === 'dark' ? 'gray-900' : 'white'} sticky top-0 z-50 shadow-lg`}>
      {/* Mobile menu */}
      <Transition.Root show={open} as={Fragment}>
        <Dialog as="div" className="relative z-40 lg:hidden" onClose={setOpen}>
          <Transition.Child
            as={Fragment}
            enter="transition-opacity ease-linear duration-300"
            enterFrom="opacity-0"
            enterTo="opacity-100"
            leave="transition-opacity ease-linear duration-300"
            leaveFrom="opacity-100"
            leaveTo="opacity-0"
          >
            <div className="fixed inset-0 bg-black bg-opacity-25" />
          </Transition.Child>
          <div className="fixed inset-0 z-40 flex">
            <Transition.Child
              as={Fragment}
              enter="transition ease-in-out duration-300 transform"
              enterFrom="-translate-x-full"
              enterTo="translate-x-0"
              leave="transition ease-in-out duration-300 transform"
              leaveFrom="translate-x-0"
              leaveTo="-translate-x-full"
            >
              <Dialog.Panel className={`relative flex w-full max-w-xs flex-col overflow-y-auto bg-${mode === 'dark' ? 'gray-800' : 'white'} pb-12 shadow-xl`}>
                <div className="flex px-4 pb-2 pt-28">
                  <button
                    type="button"
                    className="-m-2 inline-flex items-center justify-center rounded-md p-2 text-gray-400"
                    onClick={() => setOpen(false)}
                  >
                    <span className="sr-only">Close menu</span>
                    <RxCross2 />
                  </button>
                </div>
                <div className="space-y-6 border-t border-gray-200 px-4 py-6">
                  <Link to={'/'} className={`flex items-center text-sm font-medium text-gray-900 hover:text-indigo-600 ${pathname === '/' ? 'border-b-4 border-indigo-500' : ''}`} style={{ color: mode === 'dark' ? 'white' : '' }}>
                    <TbBrandGoogleHome className="mr-2" />Home
                  </Link>
                  <Link to={'/allmovies'} className={`flex items-center text-sm font-medium text-gray-900 hover:text-indigo-600 ${pathname === '/allmovies' ? 'border-b-4 border-indigo-500' : ''}`} style={{ color: mode === 'dark' ? 'white' : '' }}>
                    <BiMoviePlay className="mr-2" /> All Movies
                  </Link>
                  <Link to={'/mybookinginfo'} className={`flex items-center text-sm font-medium text-gray-900 hover:text-indigo-600 ${pathname === '/mybookinginfo' ? 'border-b-4 border-indigo-500' : ''}`} style={{ color: mode === 'dark' ? 'white' : '' }}>
                    <MdBookOnline className="mr-2" /> My Booking
                  </Link>
                  <Link to={'/dashboard'} className={`flex items-center text-sm font-medium text-gray-900 hover:text-indigo-600 ${pathname === '/dashboard' ? 'border-b-4 border-indigo-500' : ''}`} style={{ color: mode === 'dark' ? 'white' : '' }}>
                    <MdOutlineAdminPanelSettings className="mr-2" /> Admin
                  </Link>
                  <Link to={'/userprofile'} className={`flex items-center text-sm font-medium text-gray-900 hover:text-indigo-600 ${pathname === '/userprofile' ? 'border-b-4 border-indigo-500' : ''}`} style={{ color: mode === 'dark' ? 'white' : '' }}>
                    <CgProfile className="mr-2" /> My Profile
                  </Link>
                  <Link to={'/signup'} className={`flex items-center text-sm font-medium text-gray-900 hover:text-indigo-600 ${pathname === '/signup' ? 'border-b-4 border-indigo-500' : ''}`} style={{ color: mode === 'dark' ? 'white' : '' }}>
                    <FiLogOut className="mr-2" /> Signup
                  </Link>
                  <Link to={'/login'} className={`flex items-center text-sm font-medium text-gray-900 hover:text-indigo-600 ${pathname === '/login' ? 'border-b-4 border-indigo-500' : ''}`} style={{ color: mode === 'dark' ? 'white' : '' }}>
                    <CgLogOut className="mr-2" /> Logout
                  </Link>
                  <div className="flex items-center text-sm font-medium text-gray-900" style={{ color: mode === 'dark' ? 'white' : '' }}>
                    <img className="inline-block w-10 h-10 rounded-full drop-shadow-lg" src="https://avatars.githubusercontent.com/u/810438?v=4" alt="avatar" />
                  </div>
                </div>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </Dialog>
      </Transition.Root>

      {/* Desktop */}
      <header className={`relative bg-${mode === 'dark' ? 'gray-900' : 'white'} shadow-xl`}>
        <nav aria-label="Top" className={`bg-${mode === 'dark' ? 'gray-900' : 'gray-100'} px-4 sm:px-6 lg:px-8 shadow-lg`}>
          <div className="flex h-16 items-center">
            <button
              type="button"
              className={`rounded-md p-2 lg:hidden ${mode === 'dark' ? 'bg-gray-700 text-white' : 'bg-white text-gray-400'}`}
              onClick={() => setOpen(true)}
            >
              <span className="sr-only">Open menu</span>
              <AiOutlineMenu size={25} />
            </button>
            {/* Logo */}
            <div className="ml-4 flex lg:ml-0">
              <Link to={'/'} className='flex'>
                <div className="flex items-center space-x-3 rtl:space-x-reverse">
                  <img src={Logo} className="h-8 transform transition-transform hover:scale-110" alt="Logo" />
                  <h1 className={`self-center text-2xl font-semibold whitespace-nowrap px-2 py-1 rounded drop-shadow-lg ${mode === 'dark' ? 'text-white' : 'text-black'} transition-all duration-300`}>
                    Golden Tikit
                  </h1>
                </div>
              </Link>
            </div>
            <div className="ml-auto flex items-center">
              <div className="hidden lg:flex lg:items-center lg:justify-end lg:space-x-6">
                <Link to={'/'} className={`text-sm font-medium ${pathname === '/' ? 'text-indigo-600 border-b-4 border-indigo-500' : mode === 'dark' ? 'text-white' : 'text-gray-700'} hover:text-indigo-600`}>
                  <TbBrandGoogleHome className="inline mr-1" />Home
                </Link>
                <Link to={'/allmovies'} className={`text-sm font-medium ${pathname === '/allmovies' ? 'text-indigo-600 border-b-4 border-indigo-500' : mode === 'dark' ? 'text-white' : 'text-gray-700'} hover:text-indigo-600`}>
                  <BiMoviePlay className="inline mr-1" /> All Movies
                </Link>
                <Link to={'/mybookinginfo'} className={`text-sm font-medium ${pathname === '/mybookinginfo' ? 'text-indigo-600 border-b-4 border-indigo-500' : mode === 'dark' ? 'text-white' : 'text-gray-700'} hover:text-indigo-600`}>
                  <MdBookOnline className="inline mr-1" /> My Booking
                </Link>
                <Link to={'/dashboard'} className={`text-sm font-medium ${pathname === '/dashboard' ? 'text-indigo-600 border-b-4 border-indigo-500' : mode === 'dark' ? 'text-white' : 'text-gray-700'} hover:text-indigo-600`}>
                  <MdOutlineAdminPanelSettings className="inline mr-1" /> Admin
                </Link>
                <Link to={'/userprofile'} className={`text-sm font-medium ${pathname === '/userprofile' ? 'text-indigo-600 border-b-4 border-indigo-500' : mode === 'dark' ? 'text-white' : 'text-gray-700'} hover:text-indigo-600`}>
                  <CgProfile className="inline mr-1" /> My Profile
                </Link>
                <Link to={'/signup'} className={`text-sm font-medium cursor-pointer ${pathname === '/signup' ? 'text-indigo-600 border-b-4 border-indigo-500' : mode === 'dark' ? 'text-white' : 'text-gray-700'} hover:text-indigo-600`}>
                  <FiLogOut className="inline mr-1" /> Signup
                </Link>
                <Link to={'/login'} className={`text-sm font-medium cursor-pointer ${pathname === '/login' ? 'text-indigo-600 border-b-4 border-indigo-500' : mode === 'dark' ? 'text-white' : 'text-gray-700'} hover:text-indigo-600`}>
                  <CgLogOut className="inline mr-1" /> Logout
                </Link>
              </div>
              {/* Toggle Mode */}
              <div className="flex lg:ml-6">
                <button onClick={toggleMode} className="hover:text-indigo-600 transition duration-300 ease-in-out">
                  {mode === 'light' ? (
                    <FiSun size={30} />
                  ) : (
                    <MdOutlineNightsStay size={30} style={{ color: mode === 'dark' ? 'white' : '' }} />
                  )}
                </button>
              </div>
              {/* Cart */}
              <div className="ml-4 flow-root lg:ml-6">
                <Link to={'/paycart'} className={`group -m-2 flex items-center p-2 ${mode === 'dark' ? 'text-white' : 'text-gray-700'} hover:text-indigo-600 transition duration-300 ease-in-out`}>
                  <GiTicket className='hover:text-pink-600' size={25} />
                  <span className="ml-2 text-sm font-medium">0</span>
                  <span className="sr-only">Booking in cart, view bag</span>
                </Link>
              </div>
              {/* User Avatar */}
              <div className="flex items-center ml-4 cursor-pointer drop-shadow-lg transition-transform hover:scale-110">
                <img className="inline-block w-10 h-10 rounded-lg" src="https://avatars.githubusercontent.com/u/810438?v=4" alt="avatar" />
              </div>
            </div>
          </div>
        </nav>
      </header>
    </div>
  );
}
