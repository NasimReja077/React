import React from 'react'

function PayModal() {
  return (
    <div>PayModal</div>
  )
}

export default PayModal