import React from 'react'

function Cards() {
  return (
    <div>Cards</div>
  )
}

export default Cards