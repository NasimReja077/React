import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import ReactPlayer from "react-player";
import { FaArrowLeft, FaFilm, FaStar, FaCalendarAlt, FaTags } from "react-icons/fa";

const VideoPlayer = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const { state: movie } = location;

    if (!movie) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-black text-white">
                No movie selected
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-900 text-white p-4 flex flex-col items-center relative ">
            <button
                className="absolute top-4 left-4 text-lg hover:text-gray-300 transition duration-300 flex justify-between text-center m-1 p-2"
                onClick={() => navigate(-1)}
            >
                <FaArrowLeft className="hover:-translate-x-1 transition-transform duration-300 animate-pulse text-center m-2" /> Back
            </button>
            <div className="mb-4 text-center shadow-lg p-6 rounded-lg bg-gray-800 hover:bg-gray-700 transition duration-300 transform hover:-translate-y-1 mt-12">
                <h1 className="text-2xl font-bold mb-2">{movie.title}</h1>
                <div className="flex justify-center items-center space-x-4 text-sm text-gray-400">
                    <div className="flex items-center">
                        <FaCalendarAlt className="mr-1" /> {movie.release_date}
                    </div>
                    <div className="flex items-center">
                        <FaFilm className="mr-1" /> {movie.studio}
                    </div>
                    <div className="flex items-center">
                        <FaStar className="mr-1" /> {movie.rating}
                    </div>
                    <div className="flex items-center">
                        <FaTags className="mr-1" /> {movie.genres.join(', ')}
                    </div>
                </div>
            </div>
            <div className="mb-4 w-full max-w-4xl shadow-lg rounded-md overflow-hidden transform hover:-translate-y-1 transition duration-300">
                <ReactPlayer
                    url={movie.video_url}
                    playing
                    controls
                    width="100%"
                    height="60vh"
                    className="rounded-md"
                />
            </div>
            <div className="max-w-4xl text-center shadow-lg p-6 rounded-lg bg-gray-800 hover:bg-gray-700 transition duration-300 transform hover:-translate-y-1">
                <p className="leading-relaxed">{movie.description}</p>
            </div>
        </div>
    );
};

export default VideoPlayer;
