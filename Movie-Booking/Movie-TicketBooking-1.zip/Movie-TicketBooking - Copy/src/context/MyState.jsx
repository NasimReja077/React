import React, { useState } from 'react'
import MyContext from './myContext'
function MyState(props) {
     const [mode, setMode] = useState('light');
     const toggleMode = () => {
          if (mode === 'light') {
               setMode('dark');
               document.body.style.backgroundColor = 'rgb(25, 39, 52)';
               document.body.classList.remove
          } else {
               setMode('light');
               document.body.style.backgroundColor = 'rgb(228, 230, 235)';
               document.body.classList.remove
          }
        };
  return (
     <MyContext.Provider value={{mode, toggleMode}}>
          { props.children }
     </MyContext.Provider>
  )
}

export default MyState

