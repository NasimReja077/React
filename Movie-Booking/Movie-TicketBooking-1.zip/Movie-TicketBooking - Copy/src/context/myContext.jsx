import {createContext} from 'react';

const myContext = createContext();
export default myContext;

