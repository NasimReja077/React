import React from 'react'

function AddMovie() {
  return (
    <div>AddMovie</div>
  )
}

export default AddMovie