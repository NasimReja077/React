import React from 'react'

function UpdateMovie() {
  return (
    <div>UpdateMovie</div>
  )
}

export default UpdateMovie