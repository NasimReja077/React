import React from 'react'

function DasboardTab() {
  return (
    <div>DasboardTab</div>
  )
}

export default DasboardTab