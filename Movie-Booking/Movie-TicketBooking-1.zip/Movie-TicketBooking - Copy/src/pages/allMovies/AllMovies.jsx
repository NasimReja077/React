import React from 'react'

function AllMovies() {
  return (
    <div>AllMovies</div>
  )
}

export default AllMovies