import React from 'react'

function MyBookingInfo() {
  return (
    <div>MyBookingInfo</div>
  )
}

export default MyBookingInfo