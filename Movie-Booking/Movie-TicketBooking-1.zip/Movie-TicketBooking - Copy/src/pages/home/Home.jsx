import React, { useContext } from 'react';
import Layout from '../../components/layout/Layout';
import myContext from '../../context/myContext';
import HeroSection from '../../components/heroSection/HeroSection';
import MovieCard from '../../components/movieCard/MovieCard';

function Home() {
  const context = useContext(myContext);
  console.log(context);  
  return (
    <Layout>
      <HeroSection/>
      <MovieCard/>
    </Layout>
  );
}

export default Home;
