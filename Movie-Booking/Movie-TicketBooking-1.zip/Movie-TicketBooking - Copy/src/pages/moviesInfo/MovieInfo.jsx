import React, { useContext, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import moment from 'moment';
import Layout from '../../components/layout/Layout';
import myContext from '../../context/myContext';
import { FaPlay, FaTicketAlt, FaStar, FaCalendarAlt, FaBuilding, FaTags } from 'react-icons/fa';

function MovieInfo() {
    const context = useContext(myContext);
    const navigate = useNavigate();
    const params = useParams();

    const handleTrailerClick = (movie) => {
      navigate('/player', { state: movie });
  };

    // Dummy data for demo
    const movie = {
        title: "The Flash",
        tagline: "Worlds collide.",
        vote_average: 7.5,
        vote_count: 1200,
        runtime: 144,
        description: "Barry Allen uses his super speed to change the past, but his attempt to save his family creates a world without superheroes, forcing him to race for his life.",
        status: "Released",
        release_date: "2023-06-16",
        revenue: 300000000,
        studio: "Warner Bros.",
        genres: ["Action", "Adventure", "Sci-Fi"],
        backdrop_path: "https://static.dc.com/2023-05/Movies_Thumb_TheFlash.jpg?w=640",
        poster_path: "https://i.pinimg.com/736x/24/23/0c/24230cbb4633373592edcb278afcef1c.jpg",
        video_url: 'https://youtu.be/hebWYacbdvc',
    };

    const castData = {
        crew: [{ name: "Andy Muschietti" }],
        cast: [
            { name: "Ezra Miller", profile_path: "https://imagez.tmz.com/image/4f/4by3/2022/08/16/4f293ce6c44e4bf4814c358eca60ac51_md.jpg" },
            { name: "Michael Keaton", profile_path: "https://media.vanityfair.com/photos/62e92ee5e157986bb4f403e4/master/w_1920,c_limit/1402978977.jpg" }
        ]
    };

    const duration = (movie.runtime / 60).toFixed(1).split(".");
    const writer = "Christina Hodson";

    return (
        <Layout>
            <div className={`min-h-screen ${context.mode === 'dark' ? 'bg-gray-900 text-white' : 'bg-gray-100 text-black'}`}>
                <div className='w-full h-[280px] relative hidden lg:block'>
                    <div className='w-full h-full'>
                        <img
                            src={movie.backdrop_path}
                            className='h-full w-full object-cover'
                            alt="Backdrop"
                        />
                    </div>
                    <div className='absolute w-full h-full top-0 bg-gradient-to-t from-neutral-900/90 to-transparent'></div>
                </div>

                <div className='container mx-auto px-3 py-16 lg:py-0 flex flex-col lg:flex-row gap-5 lg:gap-10'>
                    <div className='relative mx-auto lg:-mt-28 lg:mx-0 w-fit min-w-60'>
                        <img
                            src={movie.poster_path}
                            className='h-80 w-60 object-cover rounded shadow-lg hover:scale-105 transition-transform duration-300'
                            alt="Poster"
                        />
                        
                        <div className="flex justify-between mt-3 space-x-2">
                                    <button className="bg-gradient-to-r from-pink-500 to-purple-500 text-white px-4 py-2 rounded-md flex items-center hover:from-pink-600 hover:to-purple-600 transition duration-300">
                                        <FaTicketAlt className="mr-2" /> Book Now
                                    </button>
                                    <button
                                        className="bg-blue-500 text-white px-4 py-2 rounded-md flex items-center hover:bg-blue-600 transition duration-300"
                                        onClick={() => handleTrailerClick(movie)} // Pass the movie object
                                    >
                                        <FaPlay className="mr-2" /> Trailer
                                    </button>
                                </div>
                      </div>

                    <div>
                        <h2 className='text-2xl lg:text-4xl font-bold'>{movie.title}</h2>
                        <p className='text-neutral-400 mb-4'>{movie.tagline}</p>

                        <div className='flex items-center gap-3 mb-4'>
                            <p>Rating: {Number(movie.vote_average).toFixed(1)}+</p>
                            <span>|</span>
                            <p>View: {Number(movie.vote_count)}</p>
                            <span>|</span>
                            <p>Duration: {duration[0]}h {duration[1]}m</p>
                        </div>

                        <div className='mb-4'>
                            <h3 className='text-xl font-bold mb-1'>Overview</h3>
                            <p>{movie.description}</p>
                        </div>

                        <div className='flex items-center gap-3 my-3'>
                            <p><FaBuilding className="mr-1" /> Studio: {movie.studio}</p>
                            <span>|</span>
                            <p><FaTags className="mr-1" /> Genres: {movie.genres.join(', ')}</p>
                        </div>

                        <div className='mb-4'>
                            <p><span className='font-bold'>Director</span>: {castData.crew[0].name}</p>
                            <p><span className='font-bold'>Writer</span>: {writer}</p>
                        </div>

                        <div className='mb-4'>
                            <h2 className='font-bold text-lg'>Cast:</h2>
                            <div className='grid grid-cols-[repeat(auto-fit,96px)] gap-5 my-4'>
                                {castData.cast.map((starCast, index) => (
                                    <div key={index} className='text-center'>
                                        <img
                                            src={starCast.profile_path}
                                            className='w-24 h-24 object-cover rounded-full shadow-lg hover:scale-105 transition-transform duration-300'
                                            alt={starCast.name}
                                        />
                                        <p className='font-bold text-sm text-neutral-400'>{starCast.name}</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </Layout>
    );
}

export default MovieInfo;
