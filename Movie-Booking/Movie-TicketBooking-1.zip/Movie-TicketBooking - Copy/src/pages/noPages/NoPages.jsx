import React from 'react'

function NoPages() {
  return (
    <div>NoPages</div>
  )
}

export default NoPages