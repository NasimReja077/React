import React from 'react'

function PayCart() {
  return (
    <div>PayCart</div>
  )
}

export default PayCart



