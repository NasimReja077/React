import { Link } from 'react-router-dom';
import { useContext, useState } from 'react';
import myContext from '../../../context/myContext';
// import { toast } from 'react-toastify';
// import { createUserWithEmailAndPassword } from 'firebase/auth';
// import { auth, fireDB } from '../../firebase/FirebaseConfig';
// import { collection, addDoc, Timestamp } from 'firebase/firestore';
// import Loader from '../../components/loader/Loader';

function Signup() {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const context = useContext(myContext);
    const { loading, setLoading } = context;

    const signup = async (e) => {
        e.preventDefault();
        setLoading(true);
        if (name === "" || email === "" || password === "") {
            setLoading(false);
            return toast.error("All fields are required");
        }

        try {
            const userCredential = await createUserWithEmailAndPassword(auth, email, password);
            const user = {
                name: name,
                uid: userCredential.user.uid,
                email: userCredential.user.email,
                time: Timestamp.now()
            };

            const userRef = collection(fireDB, "users");
            await addDoc(userRef, user);
            toast.success("Signup Successfully");
            setName("");
            setEmail("");
            setPassword("");
        } catch (error) {
            console.error("Error signing up:", error);
            toast.error("Signup Failed: " + error.message);
        } finally {
            setLoading(false);
        }
    }

    return (
        <div className="flex justify-center items-center min-h-screen bg-gray-900">
            {loading && <Loader />}
            <div className="bg-gray-800 px-10 py-10 rounded-xl w-full max-w-md shadow-lg transform transition-all duration-300 hover:shadow-2xl">
                <h1 className="text-center text-white text-3xl mb-4 font-bold">Signup</h1>
                <form className="space-y-4" onSubmit={signup}>
                    <div>
                        <input
                            type="text"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            name="name"
                            className="bg-gray-600 mb-4 px-3 py-2 w-full rounded-lg text-white placeholder-gray-400 outline-none focus:ring-2 focus:ring-red-500"
                            placeholder="Name"
                        />
                    </div>
                    <div>
                        <input
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            name="email"
                            className="bg-gray-600 mb-4 px-3 py-2 w-full rounded-lg text-white placeholder-gray-400 outline-none focus:ring-2 focus:ring-red-500"
                            placeholder="Email"
                        />
                    </div>
                    <div>
                        <input
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="bg-gray-600 mb-4 px-3 py-2 w-full rounded-lg text-white placeholder-gray-400 outline-none focus:ring-2 focus:ring-red-500"
                            placeholder="Password"
                        />
                    </div>
                    <div className="flex justify-center">
                        <button
                            type="submit"
                            className="bg-red-500 w-full text-white font-bold px-4 py-2 rounded-lg transform transition-all duration-300 hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-opacity-50"
                        >
                            Signup
                        </button>
                    </div>
                    <div className="text-center mt-4">
                        <span className="text-white">Have an account? </span>
                        <Link className="text-red-500 font-bold hover:underline" to="/login">
                            Login
                        </Link>
                    </div>
                </form>
            </div>
        </div>
    );
}

export default Signup;
