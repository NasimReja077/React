import React from 'react'

function SeatBookig() {
  return (
    <div>SeatBookig</div>
  )
}

export default SeatBookig