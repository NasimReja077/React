import React from 'react'

function UserProfile() {
  return (
    <div>UserProfile</div>
  )
}

export default UserProfile